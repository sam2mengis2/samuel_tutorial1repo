//this line prints "hello!" to the debug console
console.log("hello!");

//fill in a line that prints "hello world!"
// YOUR CODE HERE
